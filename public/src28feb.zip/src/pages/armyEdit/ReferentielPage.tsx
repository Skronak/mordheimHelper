import React, {useEffect, useState} from "react";
import ArmyEditPage from "@/pages/armyEdit/ArmyEditPage";
import {useParams} from "react-router-dom";


export function ReferentielPage() {

    useEffect(() => {
    }, []);

    return (
      <>
          <button>Army</button>
          <button>Equipment</button>
      </>
    )
}