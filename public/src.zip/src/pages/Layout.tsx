import React, {PropsWithChildren, ReactNode} from "react";
import Header from "@/pages/Header";
import Footer from "@/pages/Footer";

type Props = {
  children: ReactNode;
}
export default function Layout(props: Props){

  return (
    <>
      <Header/>
      {props.children}
      <Footer />
  </>
  )
}