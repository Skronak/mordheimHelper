import { useNavigate } from "react-router-dom";
import "./Header.css";
import {IconButton} from "@mui/material";
import React from "react";
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

export default function Header() {
  const navigate = useNavigate();

    return (
        <div className={'navigation-header'}>
          <IconButton aria-label="delete">
            <ArrowBackIcon />
          </IconButton>
          <button onClick={()=>navigate(-1)}>{'<-'}</button>
        </div>
    )
}